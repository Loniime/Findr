import { Routes } from "@angular/router";
import { SncfComponent } from '../sncf.component';

export const resultRoutes : Routes = [
    {
        path: '',
        component: SncfComponent
    }
]